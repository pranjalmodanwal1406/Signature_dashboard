import React from 'react'
import { AppContent, AppSidebar, AppFooter, AppHeader } from '../components/index'
import './Default.scss'
import './Details.scss'
import { CCard, CCardBody, CCardHeader, CRow, CCol, CButton } from '@coreui/react';
import { FaEdit, FaPlus, FaEnvelope, FaPhone, FaGlobe, FaMapMarkerAlt, FaFacebook, FaTwitter, FaLinkedin, FaGithub } from 'react-icons/fa';
import profilePic from './photo.png'; // Replace with the actual path to the profile picture

const DefaultLayout = () => {
  return (
    <div>
      <AppSidebar />
      <div className="wrapper d-flex flex-column min-vh-100">
        {/* <AppHeader /> */}
        <div className="body d-flex flex-grow-1">
          <div className='content-left'>
            <AppContent />
          </div>
          <div className='content-right'>
            <div className="dashboard">
              <CCard className="signature-card">
                <CCardBody>
                  <div className="signature-section">
                    <h3 className='right-h3 d-flex align-items-center justify-content-center'>
                      My Signature
                    </h3>
                    <p className='right-p'>Selected Template</p>
                    <CRow>
                      <CCol className="right-section">
                        <div className="paragraphs">
                          <div className="signature-box">
                            <CRow>
                              <CCol className="profile-pic">
                                <img src={profilePic} alt="Profile" />
                              </CCol>
                              <CCol className="user-info">
                                <p className='cname'>John Doe</p>
                                <p className='crole'>Developer</p>
                                <p className='csocial'>
                                  <FaFacebook className="social-icon" />
                                  <FaTwitter className="social-icon" />
                                  <FaLinkedin className="social-icon" />
                                  <FaGithub className="social-icon" />
                                </p>
                                <p>Core</p>
                              </CCol>
                              <CCol md="5" className="contact-info">
                                <p><FaEnvelope />user@example.com</p>
                                <p><FaPhone /> (123) 456-7890</p>
                                <p><FaGlobe />www.example.com</p>
                                <p><FaMapMarkerAlt />123 Main St, City, Country</p>
                              </CCol>
                            </CRow>
                          </div>
                        </div>
                      </CCol>
                    </CRow>
                  </div>
                  <div className='button-container'>
                    <button className='right-button d-flex align-items-center justify-content-center'>Done</button>
                  </div>
                </CCardBody>
              </CCard>
            </div>
          </div>
        </div>
        <AppFooter />
      </div>
    </div>
  )
}

export default DefaultLayout
