import React from 'react';
import { CCard, CCardBody, CCardHeader, CRow, CCol, CButton } from '@coreui/react';
import './Details.scss';
import { FaEdit, FaPlus, FaEnvelope, FaPhone, FaGlobe, FaMapMarkerAlt, FaFacebook, FaTwitter, FaLinkedin, FaGithub } from 'react-icons/fa';
import profilePic from './photo.png'; // Replace with the actual path to the profile picture

const Details = () => {
    return (
       <>
       <div className="dashboard">

<CCard className="signature-card">
  <CCardBody>
    <div className="signature-section">
      <CRow>
        <CCol className="left-section">
          <h1>Signature Details</h1>
          <div className="user-info">
            <div className="field">
              <input type="text" placeholder="Name" />
            </div>
            <div className="field">
              <input type="text" placeholder="Title" />
            </div>
            <div className="field">
              <input type="text" placeholder="Company" />
            </div>
            <div className="field">
              <input type="tel" placeholder="Mobile" />
            </div>
            <div className="field">
              <input type="tel" placeholder="Phone" />
            </div>
            <div className="field">
              <input type="email" placeholder="Email" />
            </div>
            <div className="field">
              <input type="text" placeholder="Website" />
            </div>
            <div className="field">
              <input type="text" placeholder="Address" />
            </div>
            upload
            <CButton className="create-signature-button">
              <FaPlus />   <span className='px-2'>Create Signature</span>
            </CButton>

          </div>
        </CCol>
      </CRow>
    </div>
  </CCardBody>
</CCard>


</div>
       </>
    );
}

export default Details;
