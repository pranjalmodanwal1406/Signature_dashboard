import React from 'react';
import { CCard, CCardBody, CCardHeader, CRow, CCol, CButton } from '@coreui/react';
import './dashboard.scss'
import { FaEdit, FaPlus, FaEnvelope, FaPhone, FaGlobe, FaMapMarkerAlt, FaFacebook, FaTwitter, FaLinkedin, FaGithub } from 'react-icons/fa';
import profilePic from './photo.png'; // Replace with the actual path to the profile picture

const Dashboard = () => {
  return (
    <div className="dashboard">
      <h1>My signatures</h1>

      <CCard className="signature-card">
        <CCardHeader className="card-header">
          <p>My Signature</p>
          <p className='down-btn'>⬇</p>
        </CCardHeader>
        <CCardBody>
          <div className="email-section">
            <h5>Email Address:</h5>
            <p className='ename'>user@example.com</p>
          </div>

          <div className="signature-section">
            <h5>Signature:</h5>
            <div className="signature-box">
              <CRow>
                <CCol className="profile-pic">
                  <img src={profilePic} alt="Profile" />
                </CCol>
                <CCol className="user-info">
                  <p className='cname'>John Doe</p>
                  <p className='crole'>Developer</p>
                  <p className='csocial'>
                    <FaFacebook className="social-icon" />
                    <FaTwitter className="social-icon" />
                    <FaLinkedin className="social-icon" />
                    <FaGithub className="social-icon" />

                  </p>
                  <p>Core</p>
                </CCol>
                <CCol md="5" className="contact-info">
                  <p><FaEnvelope />user@example.com</p>
                  <p><FaPhone /> (123) 456-7890</p>
                  <p><FaGlobe />www.example.com</p>
                  <p><FaMapMarkerAlt />123 Main St, City, Country</p>
                </CCol>
              </CRow>

            </div>
            <CButton color="light" className="edit-button">
              Edit
            </CButton>
          </div>
        </CCardBody>
      </CCard>

      <CButton className="create-signature-button">
        <FaPlus />   <span className='px-2'>Create Signature</span>
      </CButton>
    </div>
  );
}

export default Dashboard;
